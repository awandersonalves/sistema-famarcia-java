/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.lang.System.Logger;
import java.lang.System.Logger.Level;

/**
 *
 * @author PC
 */
public class Produto {
    public String nome;
    public int qtd;
    public String valor;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getQtd() {
        return qtd;
    }

    public void setQtd(int qtd) {
        this.qtd = qtd;
    }

    public String getValor() {
        return valor;
    }

    public void setValor(String valor) {
        this.valor = valor;
    }
    
    public String salvar(){
        try{
        FileWriter fw = new FileWriter("produto.txt");
            PrintWriter pw = new PrintWriter(fw);
            pw.println(this.nome);
            pw.println(this.qtd);
            pw.println(this.valor);
            pw.flush();//n armazena em buffer
            pw.close();
            fw.close();
        }catch(IOException ex){
            
        }        
        return "Cadastrado com sucesso!";
    }
    
    public String read(String caminho){
        String conteudo = "";
        try{
            FileReader arq = new FileReader(caminho);
            BufferedReader lerArq = new BufferedReader(arq);
            
            String linha = "";
            try{
                linha = lerArq.readLine();
                while(linha != null){
                conteudo += linha;
                }
            }
            catch(IOException ex){
            
            }
        }
        catch(IOException ex){
            
        }
        
        return null;
        
    }
}
