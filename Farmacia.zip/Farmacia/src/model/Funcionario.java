/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

/**
 *
 * @author PC
 */
public class Funcionario {
    private String nome;
    private int idade;
    private long numero;
    
    public void Funcionario(String nome, int idade, long numero){
        nome = this.nome;
        idade = this.idade;
        numero = this.numero;
    }
    
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public long getNumero() {
        return numero;
    }

    public void setNumero(long numero) {
        this.numero = numero;
    }
    
    public String salvar(){
        try{
        FileWriter fw = new FileWriter("funcionario.txt");
            PrintWriter pw = new PrintWriter(fw);
            pw.println(this.nome);
            pw.println(this.idade);
            pw.println(this.numero);
            pw.flush();//n armazena em buffer
            pw.close();
            fw.close();
        }catch(IOException ex){
            
        }
        
        
        return "Cadastrado com sucesso!";
    }
}
