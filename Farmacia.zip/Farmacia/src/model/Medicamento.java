/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author PC
 */
public class Medicamento extends Produto {
    public int numControle = 0;
    
    public void Medicamento(String nome, int qtd, String valor, int numControle){
        nome = this.nome;
        qtd = this.qtd;
        valor = this.valor;
        numControle = this.numControle;
    }

    public int getNumControle() {
        return numControle;
    }

    public void setNumControle(int numControle) {
        this.numControle = numControle;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getQtd() {
        return qtd;
    }

    public void setQtd(int qtd) {
        this.qtd = qtd;
    }

    public String getValor() {
        return valor;
    }

    public void setValor(String valor) {
        this.valor = valor;
    }
    
    

}
