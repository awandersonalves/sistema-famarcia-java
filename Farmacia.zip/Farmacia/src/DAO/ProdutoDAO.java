/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import java.io.FileWriter;
import java.io.IOException;
import model.Produto;

/**
 *
 * @author PC
 */
public class ProdutoDAO {
    public void cadastrar(Produto p) throws IOException{
        FileWriter arq = new FileWriter("c:\\produto.txt");        
    }
}
